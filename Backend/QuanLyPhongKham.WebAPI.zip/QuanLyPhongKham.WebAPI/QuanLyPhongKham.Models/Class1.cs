﻿namespace QuanLyPhongKham.Models
{
    public class Class1
    {

    }
}
