﻿namespace QuanLyPhongKham.Data
{
    public class Class1
    {

    }
}
