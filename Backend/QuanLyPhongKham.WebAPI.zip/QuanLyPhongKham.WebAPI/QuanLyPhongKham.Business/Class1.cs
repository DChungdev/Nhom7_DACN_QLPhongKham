﻿namespace QuanLyPhongKham.Business
{
    public class Class1
    {

    }
}
