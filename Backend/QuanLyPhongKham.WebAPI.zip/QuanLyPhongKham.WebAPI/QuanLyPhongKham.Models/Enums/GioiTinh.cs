﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyPhongKham.Models.Enums
{
    public enum GioiTinh
    {
        Nam = 0,
        Nu = 1,
        Khac = 2
    }
}
