﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyPhongKham.Models.Enums
{
    public enum TrinhDo
    {
        GiaoSuYKhoa = 0,
        PhoGiaoSuYKhoa = 1,
        TienSiYKhoa = 2,
        BacSiChuyenKhoa2 = 3,
        ThacSiYKhoa = 4,
        BacSiChuyenKhoa1 = 5,
        BacSiDaKhoa = 6
    }
}
